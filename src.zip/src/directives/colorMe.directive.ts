import { Directive, Input, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[appColorMe]'
})
export class ColorMe {

    @Input('appColorMe') private color;

    constructor(private elementRef: ElementRef) {}

    @HostListener('mouseenter')
    private onMouseEnter() {
        this.colorMe(this.color);
    }

    @HostListener('mouseleave')
    private onMouseLeave() {
        this.colorMe('');
    }

    private colorMe(color) {
        this.elementRef.nativeElement.style.background = color;
    }
}
