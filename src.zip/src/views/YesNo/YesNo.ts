import { Component } from '@angular/core';

import YesNoService from '../../services/yesno.service';

@Component({
    selector: 'app-yesno',
    templateUrl: './YesNo.html'
})
export class YesNo {
    public responseLoading = false;

    public yesNoResponse  = {
        answer: '',
        imageUrl: ''
    };

    constructor(private yesNoService: YesNoService) {
        this.fetchYesNoResponse();
    }

    public fetchYesNoResponse() {
        const yesNoPromise = this.yesNoService.fetchYesNoResponse();

        yesNoPromise.then((data: any) => {
            this.yesNoResponse.answer = data.answer;
            this.yesNoResponse.imageUrl = data.image;
        });
    }
}
