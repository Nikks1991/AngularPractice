import { Component } from '@angular/core';

@Component({
    selector: 'app-intro',
    templateUrl: './IntroComponent.html'
})
export class IntroComponent {
    public paraStyle = {'background-color': 'gold', color: 'white'};
}
