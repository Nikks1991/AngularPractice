import { Component } from '@angular/core';

import DataService from '../../../../services/data.service';

@Component({
    selector: 'app-list-places',
    templateUrl: './Places.html'
})
export class Places {

    public places = [];

    constructor(private data: DataService) {
        this.places = data.fetchPlaces();
    }

    public itemSelected(evt) {
        console.log('Parent: Item Selected', evt);
    }

}
