import { Component } from '@angular/core';
import { Router } from '@angular/router';
import DataService from '../../../../services/data.service';

@Component({
    selector: 'app-list-car',
    templateUrl: './Cars.html'
})
export class Cars {

    public carList = [];

    constructor(private router: Router, private data: DataService) {

        const promise = data.fetchCars();
        promise.then((cars: any) => {
            this.carList = cars;
        });
    }

    public itemSelected(evt) {
        console.log('Parent: Item Selected', evt);
        this.router.navigate([`/car-details`, evt]);
    }

}
