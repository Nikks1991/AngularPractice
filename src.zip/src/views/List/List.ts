import { Component } from '@angular/core';

@Component({
    selector: 'app-list-view',
    templateUrl: './List.html'
})
export class List {

}
