import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-car-details',
    templateUrl: './CarDetails.html'
})
export class CarDetails {

    private brand = 'Audi';

    private carDetails = {

      Audi: `Audi AG is a German automobile manufacturer that designs, engineers, produces,
         markets and distributes luxury vehicles. Audi is a member of the Volkswagen Group
         and has its roots at Ingolstadt, Bavaria, Germany.`,

      Toyota: `Toyota Motor Corporation, usually shortened to Toyota, is a Japanese
        multinational automotive manufacturer headquartered in Toyota, Aichi, Japan.`,

      VW: `Volkswagen, shortened to VW, is a German automaker founded on 28 May 1937
        by the German Labour Front under Adolf Hitler and headquartered in Wolfsburg`,

      Dodge: `Dodge is an American brand of automobile manufactured by FCA US LLC, based in Auburn Hills, Michigan.`,

      SAAB: `Saab Automobile AB was a manufacturer of automobiles that was founded in Sweden in 1945 when its parent
        company, SAAB AB, began a project to design a small automobile. The first production model, the Saab 92, was launched in 1949.`,

      Maserati: `Maserati is an Italian luxury vehicle manufacturer established on 1 December 1914, in Bologna.
        The Maserati tagline is "Luxury, sports and style cast in exclusive cars", and the brand's mission statement ...`

    };

    constructor(private activatedRoute: ActivatedRoute) {
        this.activatedRoute.params.subscribe( params => {
            this.brand = params.name;
        });
    }

}
