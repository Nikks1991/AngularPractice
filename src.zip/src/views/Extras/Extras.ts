import { Component } from '@angular/core';

import DataService from '../../services/data.service';

@Component({
    selector: 'app-extras',
    templateUrl: './Extras.html'
})
export class Extras {
    public showText = true;
    public inputVal = 'Default Value';
    public headerText = 'This app is running in Angular 5';
    public todayDate = new Date();

    public carList = [];
    public places = [];

    constructor(private data: DataService) {

        const promise = data.fetchCars();
        promise.then((cars: any) => {
            this.carList = cars;
        });
    }

    public btnClick(evt, inputRef) {
        console.log(evt);
        this.inputVal = inputRef.value;
    }
}
