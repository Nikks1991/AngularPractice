import { Component } from '@angular/core';

@Component({
    selector: 'app-about',
    templateUrl: './AboutUs.html'
})
export class AboutUs {}
