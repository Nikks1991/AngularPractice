import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { HeaderComponent } from './../components/Header/HeaderComponent';
import { IntroComponent } from './../components/Intro/IntroComponent';
import { ListComponent } from './../components/List/ListComponent';
import { DescriptionComponent } from './../components/Description/DescriptionComponent';

@NgModule({
    declarations: [ AppComponent, HeaderComponent, IntroComponent, ListComponent, DescriptionComponent ],
    imports: [ BrowserModule ],
    bootstrap: [ AppComponent ]
})
export class AppModule {}
