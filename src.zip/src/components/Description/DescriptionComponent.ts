import { Component } from '@angular/core';

@Component({
    selector: 'app-description',
    templateUrl: './DescriptionComponent.html'
})
export class DescriptionComponent {
    public value = 1;

    public inputValue = 'Default';

    public dextersPic = `https://m.media-amazon.com/images/M/MV5BMzdlMDMxNzItNmViNS00NDRkLTg3OWMtNjliZGIxY2M5N2YyXkEyXkFqcGdeQXVyNTA4NzY1MzY@._V1_UY268_CR1,0,182,268_AL_.jpg`;

    public toggleLorem(evt, inputElm) {
        console.log('Input Velue', this.inputValue, inputElm.value);
        this.inputValue = inputElm.value + '***';
    }
}
