import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-list',
    templateUrl: './ListComponent.html'
})
export class ListComponent {

    @Input() public list = [];
    public fontSize = '18px';

    @Output() itemClick = new EventEmitter();

    public itemClicked(evt, item) {
         console.log('itemClicked', evt, item);
         this.itemClick.emit(item);
    }
}
