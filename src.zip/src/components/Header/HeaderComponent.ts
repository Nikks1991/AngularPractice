import { Component } from '@angular/core';

@Component({
    selector: 'app-header',
    templateUrl: './HeaderComponent.html'
})
export class HeaderComponent {
   public subtitle = 'This app is running in Angular 5';
}
