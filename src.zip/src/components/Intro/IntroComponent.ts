import { Component, Input } from '@angular/core';


@Component({
    selector: 'app-intro',
    templateUrl: './IntroComponent.html'
})
export class IntroComponent {
    @Input() public text = '';
}
