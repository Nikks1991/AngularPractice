import { Injectable } from '@angular/core';

@Injectable()
export default class DataService {

    private carList = ['Toyota', 'Audi', 'VW', 'Dodge', 'SAAB', 'Maserati'];
    private places = ['Pune', 'Mumbai', 'Nagpur'];

    public fetchCars() {
        const promise = new Promise((resolve, reject) => {
          setTimeout(() => {
              resolve(this.carList);
          }, 0);
        });

        return promise;
    }

    public fetchPlaces() {
        return this.places;
    }

}
