import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export default class YesNoService {
    constructor(private http: HttpClient) {}

    public fetchYesNoResponse() {
        return this.http.get('https://yesno.wtf/api').toPromise();
    }
}
