import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'wrap'
})
export class StringWrapPipe implements PipeTransform {
    transform(value, symbol, repeatCount) {
        console.log(value, symbol, repeatCount)
        return symbol + value + symbol;
    }
}
