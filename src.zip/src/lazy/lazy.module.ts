import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LazyView } from './views/LazyView/LazyView';

const routes: Routes = [
    {
        path: '',
        component: LazyView
    },
    {
        path: 'xyz',
        component: LazyView
    }
];

@NgModule({
    declarations: [ LazyView ],
    imports: [ RouterModule.forChild(routes) ]
})
export class LazyModule {}
