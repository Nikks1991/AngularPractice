import { Component } from '@angular/core';

@Component({
    templateUrl: './LazyView.html'
})
export class LazyView {}
