import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-list',
    templateUrl: './ListComponent.html'
})
export class ListComponent {
    @Input() public list = [];
    @Output() public select = new EventEmitter();

    public listItemClick(item) {
        this.select.emit(item);
    }
}
