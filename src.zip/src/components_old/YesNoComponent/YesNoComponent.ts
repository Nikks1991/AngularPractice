import { Component, Input } from '@angular/core';

@Component({
    selector: 'yes-no',
    templateUrl: './YesNoComponent.html'
})
export class YesNoComponent {
    @Input() public yesNo = {
        answer: '',
        imageUrl: ''
    };
}
