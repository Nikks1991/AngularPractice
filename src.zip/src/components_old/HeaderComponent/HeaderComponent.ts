import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-header',
    templateUrl: './HeaderComponent.html'
})
export class HeaderComponent {
    @Input() public text = 'Angular 5';
    public headerClass = {'abc': true, 'xyz': true};
}
